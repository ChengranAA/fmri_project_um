Features of this early demo:

-20 random repetitions of four conditions
- Timer to see if everything follows steps of 1.5secs
- Instead of pictures, variable names
-Times were adjusted the following: Prompt(1,5secs) + Jitter (differs randomly between 3 or 6seconds) + Stimulus Period (6secs) + Rest (15secs)
- One repetiton has an overall average of 27 seconds BUT differs between 25,5 and 28,5 individually 
- 20 repetitons * 27seconds = 540Seconds. This leaves only time for 1, maximum of 2 oddball trials with a total runtime of 600secs

Missing:
- pre and post experiment rest periods + fMRI input(5) related start cue
- pictures instead of variable names
- two or three trials that contain "oddball" and require participant response